<?php 
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-12 19:46:02
 * @LastEditTime : 2022-12-15 07:46:16
 * @FilePath     : \ioucode_auth\config\system.php
 */


return [
    'host'  =>  'http://127.0.0.1:8000',
    'web_name'      =>      '科特达'
];