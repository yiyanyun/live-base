<?php
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-14 20:34:55
 * @LastEditTime : 2022-12-16 11:44:46
 * @FilePath     : \ioucode_auth\app\agent\middleware.php
 */
// 这是系统自动生成的middleware定义文件
return [
    app\agent\middleware\Auth::class
];
