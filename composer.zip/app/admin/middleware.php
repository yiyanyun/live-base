<?php
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-10 12:10:55
 * @LastEditTime : 2022-12-16 20:40:31
 * @FilePath     : \ioucode_auth\app\admin\middleware.php
 */
// 这是系统自动生成的middleware定义文件

return [
    app\admin\middleware\Auth::class,
    app\admin\middleware\Lgo::class
];
