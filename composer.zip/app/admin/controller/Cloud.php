<?php 
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-12 19:43:45
 * @LastEditTime : 2022-12-17 11:59:12
 * @FilePath     : \ioucode_auth\app\admin\controller\Cloud.php
 */

namespace app\admin\controller;

use think\facade\View;

class Cloud 
{
    public function index()
    {
        return View::fetch();
    }

    public function up()
    {
        return '请前往云端了解详情信息！！~';
    }
}