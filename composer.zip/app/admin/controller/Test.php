<?php
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-12 20:33:45
 * @LastEditTime : 2022-12-16 15:14:12
 * @FilePath     : \ioucode_auth\app\admin\controller\Test.php
 */

namespace app\admin\controller;

class Test 
{
    public function index()
    {
        return ;
    }
}

