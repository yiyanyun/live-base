<?php
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-11 12:57:27
 * @LastEditTime : 2022-12-11 14:51:28
 * @FilePath     : \ioucode_auth\app\safe\model\User.php
 */
declare (strict_types = 1);

namespace app\safe\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class User extends Model
{
    //
}
