<?php
declare (strict_types = 1);

namespace app\safe\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class Clock extends Model
{
    //
}
