<?php 
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-25 10:56:27
 * @LastEditTime : 2022-12-25 12:11:32
 * @FilePath     : \ioucode_auth\app\shop\controller\Test.php
 */

namespace app\shop\controller;


class Test 
{
    public function index()
    {
        return 123123;
        // return get_web();
    }
}