<?php
declare (strict_types = 1);

namespace app\shop\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class GoodsApp extends Model
{
    //
}
