<?php
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-22 00:10:17
 * @LastEditTime : 2022-12-25 11:00:27
 * @FilePath     : \ioucode_auth\app\shop\middleware.php
 */
// 这是系统自动生成的middleware定义文件
return [
    \app\shop\middleware\Auth::class
];
